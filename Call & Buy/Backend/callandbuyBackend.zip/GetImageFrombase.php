<?php
$pid =$_POST["pid"];
 require_once ('Connect.php');
$query='SELECT imagename FROM images WHERE pid ='.$pid.'';
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();;
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>