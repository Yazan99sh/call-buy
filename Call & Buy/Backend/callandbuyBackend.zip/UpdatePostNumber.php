<?php
$pid =$_POST["postsnumber"];
 require_once ('Connect.php');
$query='UPDATE App SET postsnumber ='.$pid.' WHERE Status="true"';
$stm=$db->prepare($query);
$stm->execute();
?>