<?php
$search =$_POST["search"];
$checkbox =$_POST["checkbox"];
$Subtype =$_POST["Subtype"];
$FromePrice =$_POST["FromePrice"];
$ToPrice =$_POST["ToPrice"];
$site =$_POST["site"];
require_once ('Connect.php');
if ($checkbox){
    if ($FromePrice=="")$FromePrice=0;
    if ($ToPrice=="")$ToPrice=99999999999;
$query="SELECT * FROM Posts WHERE description LIKE '%$search%' OR title LIKE '%$search%' ";
}
else {
    $query="SELECT * FROM Posts WHERE description LIKE '%$search%' OR title LIKE '%$search%' ";
}
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>