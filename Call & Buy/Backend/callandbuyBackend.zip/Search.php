<?php
$search =$_POST["search"];
require_once ('Connect.php');
$query="SELECT * FROM Posts WHERE description LIKE '%$search%' OR title LIKE '%$search%' ";
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>