<?php
$pid =$_POST["pid"];
$expiredDate=$_POST["expiredDate"];
 require_once ('Connect.php');
$query='UPDATE Posts SET expiredDate="'.$expiredDate.'" WHERE pid="'.$pid.'"';
$stm=$db->prepare($query);
if($stm->execute()){
   echo 'wow'; 
}
else {
    echo 'false';
}
?>