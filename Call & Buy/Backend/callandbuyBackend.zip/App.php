<?php
require_once ('Connect.php');
$query='UPDATE APP SET postsnumber='$postsnumber';
$stm=$db->prepare($query);
$stm->execute();
?>