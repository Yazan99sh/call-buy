<?php
$pid =$_POST["pid"];
require_once ('Connect.php');
$query='DELETE FROM favorite WHERE pid="'.$pid.'"';
$stm=$db->prepare($query);
$stm->execute();
?>