<?php
$pid =$_POST["pid"];
$id =$_POST["id"];
 require_once ('Connect.php');
$query='DELETE FROM favorite WHERE id="'.$id.'" and pid="'.$pid.'"';
$stm=$db->prepare($query);
$stm->execute();
?>
