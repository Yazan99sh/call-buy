<?php
$Thingtype =$_POST["Thingtype"];
$Subtype =$_POST["Subtype"];
require_once ('Connect.php');
$query='SELECT * FROM Posts WHERE Thingtype="'.$Thingtype.'" AND Subtype="'.$Subtype.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();;
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>