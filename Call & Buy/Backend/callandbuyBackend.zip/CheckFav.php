<?php
$pid =$_POST["pid"];
$id =$_POST["id"];
 require_once ('Connect.php');
$query='SELECT * FROM favorite WHERE id="'.$id.'" and pid="'.$pid.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=$stm->fetch(PDO :: FETCH_ASSOC);
echo json_encode($row,JSON_UNESCAPED_UNICODE); 
?>