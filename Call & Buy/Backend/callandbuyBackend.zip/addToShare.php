<?php
$id =$_POST["id"];
 require_once ('Connect.php');
$query='INSERT INTO Share (id) VALUES ("'.$id.'")';
$stm=$db->prepare($query);
$stm->execute();
?>