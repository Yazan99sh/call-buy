<?php
$pid =$_POST["pid"];
$id =$_POST["id"];
 require_once ('Connect.php');
$query='INSERT INTO favorite (pid,id) VALUES ('.$pid.',"'.$id.'")';
$stm=$db->prepare($query);
$stm->execute();
?>