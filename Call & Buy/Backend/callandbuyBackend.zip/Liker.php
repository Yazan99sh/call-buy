<?php
$Fromid =$_POST["Fromid"];
$Toid =$_POST["Toid"];
 require_once ('Connect.php');
$query='INSERT INTO Liker (Fromid,toid) VALUES ('.$Fromid.',"'.$Toid.'")';
$stm=$db->prepare($query);
$stm->execute();
?>