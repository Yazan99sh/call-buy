<?php
$id=$_POST["id"];
$pid=$_POST["pid"];
$tit=$_POST["title"];
$address=$_POST["address"];
$price=$_POST["price"];
$expiredDate=$_POST["expiredDate"];
$Date=$_POST["Date"];
$description=$_POST["description"];
$Thingtype=$_POST["Thingtype"];
$Subtype=$_POST["SubType"];
 require_once ('Connect.php');
$query='INSERT INTO Posts (id,pid,title,address,price,expiredDate,Date,description,Thingtype,Subtype) VALUES ("'.$id.'","'.$pid.'","'.$tit.'","'.$address.'","'.$price.'","'.$expiredDate.'","'.$Date.'","'.$description.'","'.$Thingtype.'","'.$Subtype.'")';
$stm=$db->prepare($query);
// $stm->execute();
if ($stm->execute()) { 

} else {
  echo 'false';
}
?>