<?php
$path=$_POST['path'];
unlink($path);
?>