<?php
$pid =$_POST["pid"];
$title =$_POST["title"];
$address =$_POST["address"];
$description =$_POST["description"];
$price =$_POST["price"];
$Thingtype =$_POST["Thingtype"];
$Subtype =$_POST["Subtype"];
 require_once ('Connect.php');
$query='UPDATE Posts SET Subtype="'.$Subtype.'",address="'.$address.'",title="'.$title.'",description="'.$description.'",price="'.$price.'",Thingtype="'.$Thingtype.'" WHERE pid="'.$pid.'"';
$stm=$db->prepare($query);

if($stm->execute()){
   echo 'wow'; 
}
else {
    echo 'false';
}
?>