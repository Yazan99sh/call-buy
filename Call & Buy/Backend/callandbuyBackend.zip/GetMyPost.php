<?php
$id =$_POST["id"];
require_once ('Connect.php');
$query='SELECT * FROM Posts WHERE id="'.$id.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();;
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>