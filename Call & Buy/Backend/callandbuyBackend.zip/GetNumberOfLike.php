<?php
$toid =$_POST["Toid"];
 require_once ('Connect.php');
$query='SELECT COUNT(toid) FROM Liker WHERE toid ="'.$toid.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=$stm->fetch(PDO :: FETCH_ASSOC);
echo json_encode($row,JSON_UNESCAPED_UNICODE);   
?>
