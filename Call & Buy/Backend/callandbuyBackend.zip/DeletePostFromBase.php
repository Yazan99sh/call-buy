<?php
$pid =$_POST["pid"];
 require_once ('Connect.php');
$query='DELETE FROM Posts WHERE pid="'.$pid.'"';
$stm=$db->prepare($query);
$stm->execute();
$query2='DELETE FROM images WHERE pid="'.$pid.'"';
$stm2=$db->prepare($query2);
$stm2->execute();
?>