<?php
$id =$_POST["id"];
require_once ('Connect.php');
$query='SELECT Posts.id,Posts.title,Posts.pid,Posts.description,Posts.Thingtype,Posts.price FROM Posts INNER JOIN favorite on Posts.pid=favorite.pid WHERE favorite.id="'.$id.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();;
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>