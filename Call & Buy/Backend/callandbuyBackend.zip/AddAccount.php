<?php
$username=$_POST["username"];
$phonenumber=$_POST["phonenumber"];
$password=$_POST["password"];
 require_once ('Connect.php');
$query='INSERT INTO Accounts (username,phonenumber,password) VALUES ("'.$username.'","'.$phonenumber.'","'.$password.'")';
$stm=$db->prepare($query);
// $stm->execute();
if ($stm->execute()) { 
} else {
  echo 'false';
}
?>