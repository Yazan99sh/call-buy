<?php
require_once ('Connect.php');
$query='SELECT * FROM Ads ';
$stm=$db->prepare($query);
$stm->execute();
$row=array();
$row=$stm->fetchAll();;
echo json_encode($row,JSON_UNESCAPED_UNICODE);
?>