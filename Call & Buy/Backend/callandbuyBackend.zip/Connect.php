<?php 
$dns="mysql:host=localhost;dbname=id13025119_callandbuy";
$user="id13025119_cab";
$pass="123b456b789b++";
try{
    $db=new PDO($dns,$user,$pass);
}
catch (PDOException $e){
    // $error=$e->getMessage();
    echo "Somthing is wrong ";
    
}
?>