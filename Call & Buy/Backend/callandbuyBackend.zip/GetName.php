<?php
$id =$_POST["id"];
require_once ('Connect.php');
$query='SELECT username,phonenumber FROM Accounts WHERE id="'.$id.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=$stm->fetch(PDO :: FETCH_ASSOC);
echo json_encode($row,JSON_UNESCAPED_UNICODE); 
        ?>
