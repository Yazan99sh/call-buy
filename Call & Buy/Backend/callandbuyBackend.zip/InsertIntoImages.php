<?php
$pid =$_POST["pid"];
$imagename =$_POST["nameimage"];
 require_once ('Connect.php');
$query='INSERT INTO images (pid,imagename) VALUES ("'.$pid.'","'.$imagename.'")';
$stm=$db->prepare($query);
$stm->execute();
?>