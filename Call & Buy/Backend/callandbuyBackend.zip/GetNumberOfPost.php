<?php
require_once ('Connect.php');
$query='SELECT postsnumber FROM App';
$stm=$db->prepare($query);
$stm->execute();
$row=$stm->fetch(PDO :: FETCH_ASSOC);
echo json_encode($row,JSON_UNESCAPED_UNICODE);   
?>