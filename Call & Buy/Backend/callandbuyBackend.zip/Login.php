<?php
        // put your code here
//         include 'Connect.php';
// // $username=$_POST['username'];
// // $password=$_POST['password'];
// $username="يزن شيخ محمد";
// $password="12345";
// $query=$db->query("SELECT * FROM Accounts WHERE username= $username and password=$password");
// $result=array();
// while($fetchData=$query->fetch_assoc()){
//     $result[]=$fetchData;
// }
// echo json_encode($result);
$username = "";
$password = "";
if (isset($_POST["phonenumber"]) and isset($_POST["password"])) {
$username =htmlspecialchars(stripslashes(trim($_POST["phonenumber"])));
$password =htmlspecialchars(stripslashes(trim($_POST["password"])));
 require_once ('Connect.php');
$query='SELECT * FROM Accounts WHERE password="'.$password.'" and phonenumber="'.$username.'"';
$stm=$db->prepare($query);
$stm->execute();
$row=$stm->fetch(PDO :: FETCH_ASSOC);
echo json_encode($row,JSON_UNESCAPED_UNICODE);   
}
else {
    echo "not found";
}
        ?>

