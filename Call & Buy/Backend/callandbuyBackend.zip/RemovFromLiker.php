<?php
$Fromid =$_POST["Fromid"];
$Toid =$_POST["Toid"];
 require_once ('Connect.php');
$query='DELETE FROM Liker WHERE Fromid="'.$Fromid.'" and toid="'.$Toid.'"';
$stm=$db->prepare($query);
$stm->execute();
?>
